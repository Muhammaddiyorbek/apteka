from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import *
from django.utils.timezone import now
from datetime import timedelta
from django.db.models import Sum
from django.contrib.auth import authenticate



@api_view(['POST'])
def qarzPlus(request):
    data=request.data
    admin=Admin.objects.get(username=data['admin'])
    if QarzDaftar.objects.filter(full_name=data['full_name']):
        return Response({"message":"Bunday qarz mavjud!"},status=201)
    else:
        qarz=QarzDaftar.objects.create(full_name=data['full_name'],phone=data['phone'],amount=data['amount'],admin=admin)
        return Response({"full_name":qarz.full_name,"phone":qarz.phone,"amount":qarz.amount,"admin":admin,"id":qarz.id,"created_at":qarz.created_at},status=200)


@api_view(['PATCH'])
def qarzUpdate(request):
    data=request.data
    qarz=QarzDaftar.objects.get(id=data['id'])
    qarz.full_name=data['full_name']
    qarz.phone=data['phone']
    qarz.amount=data['amount']
    qarz.save()
    return Response({"full_name":qarz.full_name,"phone":qarz.phone,"amount":qarz.amount,"id":qarz.id,"created_at":qarz.created_at},status=200)


@api_view(['DELETE'])
def qarzDelete(request,qarz_id):
    qarz=QarzDaftar.objects.get(id=qarz_id)
    qarzName=qarz.full_name
    qarz.delete()
    return Response({"message":"qarz deleted","name":qarzName})

@api_view(['POST'])
def adminPlus(request):
    data=request.data
    admin=Admin.objects.create(username=data['username'],password=data['password'])
    return Response({"username":admin.username,"password":admin.password})

@api_view(['PATCH'])
def adminUpdate(request):
    data=request.data
    admin=Admin.objects.get(id=data['id'])
    admin.username=data['username']
    admin.password=data['password']
    admin.save()
    return Response({"username":admin.username,"password":admin.password})

@api_view(['PATCH'])
def updateAdminPermission(request):
    data=request.data
    admin=Admin.objects.get(username=data['admin'])
    admin.is_staff=data['is_staff']
    admin.save()
    return Response({"is_staff":admin.is_staff})

@api_view(['DELETE'])
def adminDelete(request,admin_username):
    admin=Admin.objects.get(username=admin_username)
    admin.delete()
    return Response({"message":"admin deleted"})

@api_view(['POST'])
def superAdminPlus(request):
    data=request.data
    admin=Admin.objects.create_superuser(username=data['username'],password=data['password'],is_staff=bool(data['is_staff']))
    return Response({"username":admin.username,"password":admin.password,"is_staff":'True'})

@api_view(['GET'])
def adminList(request):
    admins=Admin.objects.all()
    return Response({'username':admin.username,'password':admin.password,'is_staff':admin.is_staff} for admin in admins)

@api_view(['GET'])
def workersList(request):
    workers=Admin.objects.filter(is_staff=False)
    return Response({'username':worker.username,'password':worker.password} for worker in workers)

@api_view(['GET'])
def qarzList(request):
    qarzs=QarzDaftar.objects.all()
    return Response(qarzs.values())


@api_view(['GET'])
def statistic(request):
    today = datetime.today()
    # Bugungi hafta
    start_of_week = today - timedelta(days=today.weekday())
    end_of_week = start_of_week + timedelta(days=6)
    # Bugungi oy
    start_of_month = today.replace(day=1)
    end_of_month = start_of_month + relativedelta(months=1) - timedelta(days=1)
    # 6 oy
    six_months_ago = today - relativedelta(months=6)
    # 1 yil
    one_year_ago = today - relativedelta(years=1)
    # Bugungi kunda qo'shilgan ma'lumotlar
    today_records = QarzDaftar.objects.filter(created_at__date=today.date())
    # Bugungi haftada qo'shilgan ma'lumotlar
    week_records = QarzDaftar.objects.filter(
        created_at__date__gte=start_of_week.date(),
        created_at__date__lte=end_of_week.date()
    )
    # Bugungi oyda qo'shilgan ma'lumotlar
    month_records = QarzDaftar.objects.filter(
        created_at__date__gte=start_of_month.date(),
        created_at__date__lte=end_of_month.date()
    )
    # 6 oyda qo'shilgan ma'lumotlar
    six_month_records = QarzDaftar.objects.filter(
        created_at__date__gte=six_months_ago.date(),
        created_at__date__lte=today.date()
    )
    # 1 yilda qo'shilgan ma'lumotlar
    one_year_records = QarzDaftar.objects.filter(
        created_at__date__gte=one_year_ago.date(),
        created_at__date__lte=today.date()
    )
    context = {
        'today_qarz': today_records,
        'week_qarz': week_records,
        'month_qarz': month_records,
        'six_month_qarz': six_month_records,
        'one_year_qarz': one_year_records,
    }
    return Response(context)


@api_view(['POST'])
def login(request):
    data=request.data
    admin=authenticate(username=data.get('username'),password=data.get('password'))
    if admin:
        return Response({"is_staff":admin.is_staff},status=200)
    else:
        return Response({"message":"login failed"},status=400)
