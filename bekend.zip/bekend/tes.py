import requests 

# response=requests.post('http://127.0.0.1:8000/api/login/',data={"username":"admin","password":"ozbekiston"})
# print(response.json())


response=requests.post('http://127.0.0.1:8000/api/add-qarz/',data={"admin":"admin","full_name":"md","phone":"23888435","amount":"23434"})
print(response.json())