from django.contrib import admin
from .models import Admin, QarzDaftar

# Register your models here.
admin.site.register(Admin)
admin.site.register(QarzDaftar)