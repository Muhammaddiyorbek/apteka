from django.urls import path
from .views import *

urlpatterns = [
    path('add-qarz/',qarzPlus),
    path('update-qarz/',qarzUpdate),
    path('delete-qarz/<int:qarz_id>',qarzDelete),
    path('list-qarz/',qarzList),

    path('add-admin/',adminPlus),
    path('update-admin/',adminUpdate),
    path('delete-admin/<int:admin_id>',adminDelete),
    path('add-superadmin/',superAdminPlus),
    path('list-admin/',adminList),
    path('list-worker/',workersList),

    path('statistic/',statistic),

    path('login/',login),
]
