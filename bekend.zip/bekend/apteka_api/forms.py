from rest_framework.serializers import ModelSerializer
from .models import QarzDaftar,Admin

class QarzDaftarSerializer(ModelSerializer):
    class Meta:
        model=QarzDaftar
        fields=['full_name','phone','amount','admin']

class AdminSerializer(ModelSerializer):
    class Meta:
        model=Admin
        fields='__all__'